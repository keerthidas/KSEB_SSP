<nav class="pcoded-navbar">
    <div class="pcoded-inner-navbar main-menu mCustomScrollbar _mCS_1 mCS_no_scrollbar">
        <!-- <div class="pcoded-navigatio-lavel">Navigation</div> -->
        <ul class="pcoded-item pcoded-left-item">
				<!-- <?php if($main_menulabel==$page) ?> -->
                  <li class="active">
                      <a href="<?=admin_url('dashbaord')?>">
                          <span class="pcoded-micon"><i class="feather <?php print @$micon; ?>" <?php print @$style; ?>></i></span>
                          <span class="pcoded-mtext">Dashboard</span>
                      </a>
                  </li>

                
        </ul>
    </div>
</nav>
