
</div>
</div>
<!--  closing tag from $page & $banner -->
<footer id="tg-footer" class="tg-footer tg-haslayout">

  <div class="tg-footerbar">
    <div class="container">
      <span class="tg-copyright">&copy; 2020  |  All Rights Reserved</span>
      <nav class="tg-footernav">
        <ul>
          <li><a href="#">Developed By | Netroxe IT Solutions Pvt. Ltd.</a></li>
        </ul>
      </nav>
    </div>
  </div>
</footer>
<!--************************************
    Footer End
*************************************-->
</div>
