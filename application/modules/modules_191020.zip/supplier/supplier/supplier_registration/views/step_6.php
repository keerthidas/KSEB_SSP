<!-- <div class="pcoded-content">
	<div class="pcoded-inner-content">
		<div class="main-body">
			<div class="page-wrapper">
				<div class="page-body">
					<div class="row">
						
					</div>
				</div>
			</div>
		</div>
	</div>
</div> -->

<div class="page-header row no-gutters py-4">
	<div class="col-12 col-sm-4 text-center text-sm-left mb-0">
		<h3 class="page-title">Required Documents </h3>
	</div>
</div>


<div class="row">
	<div class="col-lg-12 ">
		<div class="card card-small ">
			<div class="card-header border-bottom">
				<!-- <h6 class="m-0">Form Inputs</h6> -->
			</div>	
			<div class="row p-0 px-3 pt-3">
				
			<div class="form-group col-md-12">
				<label for="">Incorprated Certificate</label>
						<input type="file" class="form-control" id="inputCity" placeholder="Incorprated Certificate"> 
			</div>
			<div class="form-group col-md-12">
				<label for="">PAN</label>
						<input type="file" class="form-control" id="inputCity" placeholder="PAN"> 
			</div>
			<div class="form-group col-md-12">
				<label for="">DOC 1</label>
						<input type="file" class="form-control" id="inputCity" placeholder="DOC 1"> 
			</div>
			<div class="form-group col-md-12">
				<label for="">DOC 2</label>
						<input type="file" class="form-control" id="inputCity" placeholder="DOC 2"> 
			</div>
			<!-- <div class=" col-md-6"></div> -->
			<div class="form-group align-items-end col-md-6">
				<a href="<?=supplier_url('registration/step_5')?>" class="mb-2 btn btn-outline-primary mr-2">Previous</a>
				<a href="<?=supplier_url('dashboard')?>" class="mb-2 btn btn-outline-primary mr-2">Submit</a>
				<!-- <button type="button" class="mb-2 btn btn-outline-primary mr-2">Previous</button>	 -->
			</div>

		</div>
	</div>
</div>