<aside id="tg-sidebar" class="tg-sidebar">

  <div class="tg-widget tg-catagories-widget">
    <h3>Manage Profiles</h3>
    <ul>
      <li><a href="<?=supplier_url('dashboard/profile')?>"><em>Company Profile</em></a></li>
      <li><a href="<?=supplier_url('dashboard/personal_profile')?>"><em>Personal Profile</em><i></i></a></li>
      <li><a href="<?=supplier_url('dashboard/manage_user')?>"><em>Create Users</em><i></i></a></li>
      <li><a href="<?=supplier_url('dashboard/products')?>"><em>Products</em><i></i></a></li>
        <li><a href="<?=supplier_url('dashboard/services')?>"><em>Services</em><i></i></a></li>
    </ul>
  </div>


</aside>
