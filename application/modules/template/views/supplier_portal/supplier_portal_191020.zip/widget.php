
		
      <link rel = "stylesheet"
         href = "//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
			
      <script type = "text/javascript" 
         src = "https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js">
      </script>
			
      <script type = "text/javascript" 
         src = "https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.3/jquery-ui.min.js">
      </script>




<script>
  $( function() {
    // $( "#drag-1" ).draggable();
    // $( "#drag-2" ).draggable();
  } );
  </script>
		
      <style>
         /* .ui-menu { width: 150px; } */
            .vertical-menu {
            
              width: 250px;
              z-index: 1;
              top: 0;
              left: 0;
              overflow-x: hidden;
              transition: 0.5s;
              padding-BOTTOM: 60px;
            }

            #drag-1{
              width: 250px;
            }

            .vertical-menu a {
            background-color: #eee;
            color: black;
            display: block;
            padding: 12px;
            text-decoration: none;
            }

            .vertical-menu a:hover {
            background-color: #ccc;
            }

            .vertical-menu a.active {
            background-color: #373542;
            color: white;
            }

            *{box-sizing:border-box;}
    body{font-family:Verdana;}

    
    .slide{
      width: 100px;
      height: 59px;
      border: 1px solid #ccc;
      margin: 2px;
      background-color: white;
      padding: 1em;
      transition: all 0.3s linear;
    }
    .sort-stop .slide{
      transition: none; //prevent slide transition at end 
    }
    .sorting .sortable-placeholder{ 
      transition: height 0.3s linear; //compensate slide transition at begin
      height: 0px;
    }
    .sortable-placeholder{
      height: 60px;
    }
    .slide.ui-sortable-helper{
      transition: none;
    }
    .sortable-placeholder ~ .slide:not(.ui-sortable-helper){
      transform: translateX(60px);
    }



/* // sidebar */

    .sidebar {
      /* height: 100%; */
      width: 0px;
      position: fixed;
      z-index: 1;
      top: 0;
      left: 0;
      background-color: #111;
      overflow-x: hidden;
      transition: 0.5s;
      padding-top: 60px;
    }

    .sidebar a {
      padding: 8px 8px 8px 32px;
      text-decoration: none;
      font-size: 25px;
      color: #818181;
      display: block;
      transition: 0.3s;
    }

    .sidebar a:hover {
      color: #f1f1f1;
    }

    .sidebar .closebtn {
      position: absolute;
      top: 0;
      right: 25px;
      font-size: 36px;
      margin-left: 50px;
    }

    .openbtn {
      font-size: 20px;
      cursor: pointer;
      background-color: #373542;
      color: white;
      padding: 10px 15px;
      border: none;
      margin-top:10px;
    }

    .openbtn:hover {
      background-color: #444;
    }

    #main {
      transition: margin-left .5s;
      padding: 16px;
      text-align:left;
    }


      </style>
      <script>
      $(".all-slides").sortable({
        placeholder: 'slide-placeholder',
        axis: "x",
        revert: 150,
        start: function(e, ui){
            
            placeholderHeight = ui.item.outerHeight();
            ui.placeholder.height(placeholderHeight + 15);
            $('<div class="slide-placeholder-animator" data-height="' + placeholderHeight + '"></div>').insertAfter(ui.placeholder);
        
        },
        change: function(event, ui) {
            
            ui.placeholder.stop().height(0).animate({
                height: ui.item.outerHeight() + 15
            }, 300);
            
            placeholderAnimatorHeight = parseInt($(".slide-placeholder-animator").attr("data-height"));
            
            $(".slide-placeholder-animator").stop().height(placeholderAnimatorHeight + 15).animate({
                height: 0
            }, 300, function() {
                $(this).remove();
                placeholderHeight = ui.item.outerHeight();
                $('<div class="slide-placeholder-animator" data-height="' + placeholderHeight + '"></div>').insertAfter(ui.placeholder);
            });
            
        },
        stop: function(e, ui) {
            
            $(".slide-placeholder-animator").remove();
            
        },
});



// var slides = $('.all-slides')
// slides.sortable({
//   axis:'x',
//   revert: 300,
//   placeholder: 'sortable-placeholder',
//   cursor: 'move',
//   tolerance:'pointer',
//   start: function(){
//     slides.addClass('sorting');
//   },
//   stop: function(){
//     slides
//       .addClass('sort-stop')
//       .removeClass('sorting');
//     setTimeout(function(){
//       slides.removeClass('sort-stop'); //:( ugly hack
//     }, 310);
//   }
// });
</script>
      
<script>
function openNav() {

  var width =document.getElementById("drag-1").style.width;
 
  if(width == "0" || width =="0px"){
   
    document.getElementById("drag-1").style.width = "250px";
    document.getElementById("drag-1").style.display = 'block';
    document.getElementById("drag-2").style.width = "83.33%";


  }else{
    
    document.getElementById("drag-1").style.width = "0";
    document.getElementById("drag-1").style.display = 'none';
    document.getElementById("drag-2").style.width = "100%";
    

  }
}

function closeNav() {
  document.getElementById("drag-1").style.width = 0;
}
</script>


<div class="vertical-menu sidebar1" id="drag-1">
  <a href="#" class="active">PROFILE</a>
      <a href="<?=supplier_url('dashboard/profile')?>"><em>Company Profile</em></a>
      <a href="<?=supplier_url('dashboard/personal_profile')?>"><em>Personal Profile</em><i></i></a>
      <a href="<?=supplier_url('dashboard/manage_user')?>"><em>Create Users</em><i></i></a>
      <a href="<?=supplier_url('dashboard/products')?>"><em>Products</em><i></i></a>
      <a href="<?=supplier_url('dashboard/services')?>"><em>Services</em><i></i></a>
  <a href="<?=supplier_url('procurement')?>" class="active">PROCUREMENT PLAN</a>
  <a href="<?=supplier_url('tenders')?>" class="active">TENDERS</a>
  <a href="<?=supplier_url('delivery')?>" class="active">DELIVERY</a>
      <a href="#"><em>Dispatch</em></a>
			<a href="#"><em>Check Points</em><i></i></a>
			<a href="#"><em>Shipment</em><i></i></a>
			<a href="#"><em>Order Tracking</em><i></i></a>
			<a href="#"><em>Delivery Confirmation</em><i></i></a>
  <a href="<?=supplier_url('delivery')?>" class="active">ACCOUNTS</a>
      <a href="#"><em>Payments</em></a>
			<a href="#"><em>Prepare Invoice</em><i></i></a>
			<a href="#"><em>Invoices</em><i></i></a>
  <a href="#" class="active">WORK MEASUREMENT</a>
  <a href="<?=supplier_url('purchase_order')?>" class="active">PURCHASE ORDER</a>
   
</div>

          
    








      <!--  closing from banner.php -->
      </div>
      <div class="col-md-10" id="drag-2">
  